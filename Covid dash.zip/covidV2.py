import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd
from Connection import Connection
import covidSQL as sql

external_stylesheets = ["https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"]

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


#Cases by country
con = Connection()
con.openConnection()
query = pd.read_sql_query(sql.totalCasesByCountry(), con.connection)
con.closeConnection()
dfCases = pd.DataFrame(query, columns=["country_code", "country", "amount"])
figBarCases = px.bar(dfCases.head(20), x="country", y="amount")
figMapCases = px.choropleth(dfCases, locations="country",
                            locationmode="country names",
                            color="amount", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Deaths by country
con.openConnection()
query = pd.read_sql_query(sql.totalDeathsByCountry(), con.connection)
con.closeConnection()
dfDeaths = pd.DataFrame(query, columns=["country_code", "country", "amount"])
figBarDeaths = px.bar(dfDeaths.head(20), x="country", y="amount", color_discrete_map={"name":"red"})
figMapDeaths = px.choropleth(dfDeaths, locations="country",
                            locationmode="country names",
                            color="amount", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Rates by country
con.openConnection()
query = pd.read_sql_query(sql.ratesByCountry(), con.connection)
con.closeConnection()
dfRates = pd.DataFrame(query, columns=["country_code", "country", "rate"])
figBarRates = px.bar(dfRates.head(40), x="country", y="rate", color_discrete_map={"name":"purple"})
figMapRates = px.choropleth(dfRates, locations="country",
                            locationmode="country names",
                            color="rate", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Layout
app.layout = html.Div(children=[
    html.H1(children="Covid 19 Dashboard", className="text-center"),
    html.Div(className="container-fluid", children=[
        #Row for cases        
        html.Div(className="row", children=[
            #Col for bars    
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card border-info", children=[
                    html.Div(className="card-header bg-info text-light", children=[
                        html.H3(children="Cases by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="barCasesByCountry",
                            figure=figBarCases
                        ),
                    ]),
                ]),
            ]),
            #Col for map 
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card", children=[
                    html.Div(className="card-header", children=[
                        html.H3(children="Cases by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="mapCasesByCountry",
                            figure=figMapCases
                        ),
                    ]),
                ]),
            ]),
        ]),
        #Row for deaths
        html.Div(className="row mt-4", children=[
            #Col for bars    
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card", children=[
                    html.Div(className="card-header", children=[
                        html.H3(children="Deaths by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="barBeathsByCountry",
                            figure=figBarDeaths
                        ),            
                    ]),
                ]),            
            ]),
            #Col for map 
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card", children=[
                    html.Div(className="card-header", children=[
                        html.H3(children="Deaths by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="mapDeathsByCountry",
                            figure=figMapDeaths
                        ),            
                    ]),
                ]),            
            ]),
        ]),
        #Row for rates
        html.Div(className="row mt-4 mb-4", children=[
            #Col for bars    
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card", children=[
                    html.Div(className="card-header", children=[
                        html.H3(children="Rates by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="barRatesByCountry",
                            figure=figBarRates
                        ),            
                    ]),
                ]),            
            ]),
            #Col for map 
            html.Div(className="col-12 col-xl-6", children=[
                html.Div(className="card", children=[
                    html.Div(className="card-header", children=[
                        html.H3(children="Rates by Country"),
                    ]),
                    html.Div(className="card-body", children=[
                        dcc.Graph(
                            id="mapRatesByCountry",
                            figure=figMapRates
                        ),            
                    ]),
                ]),            
            ]),
        ]),
    ]),
])

if __name__ == "__main__":
    app.run_server(debug=True)