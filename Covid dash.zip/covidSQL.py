def totalCasesByCountry():
    return """select cou.id_country as country_code, cou.name as country, max(rep.cumulative_cases) as amount
            from report rep join country cou on (rep.id_country_country = cou.id_country)
            group by cou.id_country, cou.name
            order by amount desc"""
            
def totalDeathsByCountry():
    return """select cou.id_country as country_code, cou.name as country, max(rep.cumulative_deaths) as amount
            from report rep join country cou on (rep.id_country_country = cou.id_country)
            group by cou.id_country, cou.name
            order by amount desc"""

def ratesByCountry():
    return """select id as country_code, country, round((deaths/cases)*100,3) as rate 
            from (select cou.id_country as id, cou.name as country, cast(max(rep.cumulative_deaths) as numeric) as deaths, cast(max(rep.cumulative_cases) as numeric) as cases 
	        from report rep join country cou on (rep.id_country_country = cou.id_country) 
	        group by cou.id_country, cou.name order by deaths desc) as tasa_mortalidad 
            where cases > 0 
            order by rate desc"""
