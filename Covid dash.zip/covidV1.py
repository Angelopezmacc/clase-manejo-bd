import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.express as px
import pandas as pd
from Connection import Connection
import covidSQL as sql

external_stylesheets = ["https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css"]

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


#Cases by country
con = Connection()
con.openConnection()
query = pd.read_sql_query(sql.totalCasesByCountry(), con.connection)
con.closeConnection()
dfCases = pd.DataFrame(query, columns=["country_code", "country", "amount"])
figBarCases = px.bar(dfCases.head(20), x="country", y="amount")
figMapCases = px.choropleth(dfCases, locations="country",
                            locationmode="country names",
                            color="amount", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Deaths by country
con.openConnection()
query = pd.read_sql_query(sql.totalDeathsByCountry(), con.connection)
con.closeConnection()
dfDeaths = pd.DataFrame(query, columns=["country_code", "country", "amount"])
figBarDeaths = px.bar(dfDeaths.head(20), x="country", y="amount", color_discrete_map={"name":"red"})
figMapDeaths = px.choropleth(dfDeaths, locations="country",
                            locationmode="country names",
                            color="amount", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Rates by country
con.openConnection()
query = pd.read_sql_query(sql.ratesByCountry(), con.connection)
con.closeConnection()
dfRates = pd.DataFrame(query, columns=["country_code", "country", "rate"])
figBarRates = px.bar(dfRates.head(40), x="country", y="rate", color_discrete_map={"name":"purple"})
figMapRates = px.choropleth(dfRates, locations="country",
                            locationmode="country names",
                            color="rate", 
                            hover_name="country", 
                            color_continuous_scale=["#99ccff", "#ff3333"])

#Layout
app.layout = html.Div(children=[
    html.H1(children="Covid 19 Dashboard", className="text-center"),
    html.H2(children="Cases by Country"),
    dcc.Graph(
        id="barCasesByCountry",
        figure=figBarCases
    ),
    dcc.Graph(
        id="mapCasesByCountry",
        figure=figMapCases
    ),
    html.H2(children="Deaths by Country"),
    dcc.Graph(
        id="barBeathsByCountry",
        figure=figBarDeaths
    ),
    dcc.Graph(
        id="mapDeathsByCountry",
        figure=figMapDeaths
    ),        
    html.H2(children="Rates by Country"),
    dcc.Graph(
        id="barRatesByCountry",
        figure=figBarRates
    ),
    dcc.Graph(
        id="mapRatesByCountry",
        figure=figMapRates
    ),        
])

if __name__ == "__main__":
    app.run_server(debug=True)